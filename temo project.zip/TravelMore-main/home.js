// const Variability = document.querySelector(".Day-Night");
// const body = document.querySelector("body");
// let logic = true;

// Variability.addEventListener("click", () => {
//   if (logic) {
//     body.style.backgroundImage = "url(./img/bgNigth.dda13b0508ea72b6b5f0.png)";
//   } else {
//     body.style.backgroundImage = "url(./img/bgDay.074ef37336b466c36b93.png)";
//   }
//   logic = !logic;
// });

// $(Variability).click(function () {
//   $(body).css(
//     "background-image",
//     "url(./img/bgNigth.dda13b0508ea72b6b5f0.png)"
//   );
// });

// $(document).ready(function () {
//   $(Variability).click(function () {
//     var imageUrl = "./img/bgNigth.dda13b0508ea72b6b5f0.png";
//     $(body).css("background-image", "url(" + imageUrl + ")");
//   });
// });
